@echo off
echo =====================================================
echo           Job Tracker Uninstaller
echo =====================================================
echo.
echo Stopping any running Job Tracker processes...
taskkill /F /IM JobTracker.exe 2>nul
taskkill /F /IM Job-Tracker-Setup.exe 2>nul
taskkill /F /IM app.exe 2>nul

echo Removing desktop shortcuts...
del "%USERPROFILE%\Desktop\Job Tracker.lnk" 2>nul
del "%PUBLIC%\Desktop\Job Tracker.lnk" 2>nul

echo Removing Start Menu shortcuts...
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Job Tracker.lnk" 2>nul

echo Removing app files from LocalAppData...
rmdir /S /Q "%LOCALAPPDATA%\Programs\Job Tracker" 2>nul
rmdir /S /Q "%LOCALAPPDATA%\Programs\Job-Tracker" 2>nul

echo Removing installation registry entries...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\JobTracker" /f 2>nul

echo.
echo =====================================================
echo  Job Tracker has been cleanly uninstalled.
echo =====================================================
pause

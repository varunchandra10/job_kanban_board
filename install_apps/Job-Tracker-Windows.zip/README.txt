=====================================================
         JOB TRACKER - WINDOWS DESKTOP APP
=====================================================

QUICK START:
1. Double-click "JobTracker.exe" to run the app immediately.
   (No installation required - fully portable!)
2. Works 100% offline or synced with your cloud account.
3. If you ever want to remove old shortcuts or data from
   previous installer versions, simply run "Uninstall-Job-Tracker.bat".

Enjoy tracking your career applications!
